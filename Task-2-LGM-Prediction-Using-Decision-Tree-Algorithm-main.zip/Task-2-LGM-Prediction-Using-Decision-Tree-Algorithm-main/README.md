# Task-2-LGM-Prediction-Using-Decision-Tree-Algorithm
DataSet:- https://bit.ly/3kXTdox
